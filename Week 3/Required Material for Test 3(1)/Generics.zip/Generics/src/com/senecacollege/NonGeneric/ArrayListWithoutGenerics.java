package com.senecacollege.NonGeneric;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListWithoutGenerics {
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) { 
	      ArrayList strLst = new ArrayList(); 
	      strLst.add("alpha"); // String upcast to Object implicitly 
	      strLst.add("beta"); 
	      strLst.add("charlie"); 
	     
	      for(int i=0; i<strLst.size(); i++) {
	    	  System.out.println(strLst);
	      }
	      
	      Iterator iter = strLst.iterator(); 
	      while (iter.hasNext()) { 
		 // need to explicitly downcast Object back to String
	        String str = (String)iter.next(); 
	        System.out.println(str); 
	      } 
	      
	      // Compiler/runtime cannot detect this error
	      strLst.add(Integer.valueOf(1234)); 
	      // compile ok, but runtime ClassCastException       
	      
	      String str = (String)strLst.get(3); 
	   }

}
