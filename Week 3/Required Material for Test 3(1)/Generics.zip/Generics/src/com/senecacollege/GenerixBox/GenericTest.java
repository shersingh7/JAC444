package com.senecacollege.GenerixBox;

public class GenericTest {
		   public static void main(String[] args) { 
		    
		    GenericBox<String> box1 = new GenericBox<>("Hello"); 

		    // no explicit downcasting needed
		    String str = box1.getContent(); 
		    System.out.println(box1); 

		    // autobox int to Integer
		    GenericBox<Integer> box2 = new GenericBox<>(123); 
		    // downcast to Integer, autoboxing to int 
		    int i = box2.getContent(); 
		    System.out.println(box2); 
		   
		   // autobox double to Double    
		   GenericBox<Double> box3 = new GenericBox<>(55.66); 
		   // downcast to Double, autoboxing to double   
		   double d = box3.getContent(); 
		   System.out.println(box3); 
		  } 


}
