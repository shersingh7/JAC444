package com.senecacollege.GenerixBox;

public class GenericBox<E> { 
    private E content; // Private variable 

    public GenericBox(E content) {			// Constructor 
               this.content = content; 
    } 
    public E getContent() { 
               return content; 
    } 
    public void setContent(E content) { 
               this.content = content; 
    } 
    public String toString() { 
               return content + " (" + content.getClass() + ")"; 
  } 
    
}
