package com.senecacollege.GenericsDemo;

public class GenericDemo {

	public static void main(String[] args) {
		Container<String> storeString = new Store<>();
		storeString.set("java");
		//storeString.set(1);
		System.out.println(storeString.get());

		Container<Integer> storeInteger = new Store<>();
		storeInteger.set(1);
		System.out.println(storeInteger.get());

	}

}

interface Container<T>{
	
	 void set(T a);
	 T get();
}

class Store<T> implements Container<T>{
	private T a;
	
	public void set (T a) {
		this.a = a;
	}
	
	public T get() {
		return a;
	}
}