package com.senecacollege.GenericMethod;

public class GenericsType<T> {
	private T a;
	
	public T get() {
		
		return a;
	}
	
	public void set(T a) {
		this.a = a;
	}
	
	

}
