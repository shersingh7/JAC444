package com.senecacollege.GenericArrayList;

public class GenericArrayListTest {
		   public static void main(String[] args) { 
		     // type safe to hold a list of Strings 
		     GenericArrayList<String> strLst = new GenericArrayList<>(); 
		     strLst.add("alpha"); // compiler checks if argument is of type String 
		     strLst.add("beta"); 

		     for (int i = 0; i < strLst.size(); ++i) { 
		           // compiler inserts the downcasting operator (String)        
		           String str = strLst.get(i); 
		           System.out.println(str); 
		      } 

		    // compiler detected argument is NOT String, issues compilation error
		      strLst.add(Integer.valueOf(123));
		   } 
		

}
