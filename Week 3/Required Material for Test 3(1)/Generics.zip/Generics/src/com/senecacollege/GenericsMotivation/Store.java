package com.senecacollege.GenericsMotivation;

import java.util.Date;

public class Store<T>{
	private T a;
	
	public void set(T a) {
		this.a = a;
	}
	
	public T get() {
		return a;
	}
	
	
	public static void main(String[] args) {
		Store<Date> store = new Store<Date>();
		store.set(new Date());
		
		Date date = store.get();
		
		store.set((java.sql.Date) new Date());
		
		Date date1 =  store.get(); 
	}
}

