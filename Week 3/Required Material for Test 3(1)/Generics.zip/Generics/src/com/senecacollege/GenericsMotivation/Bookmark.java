package com.senecacollege.GenericsMotivation;

public class Bookmark {

}
