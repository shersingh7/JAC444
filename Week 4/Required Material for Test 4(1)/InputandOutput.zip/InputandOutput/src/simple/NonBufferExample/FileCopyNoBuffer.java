package simple.NonBufferExample;

import java.io.*; 

public class FileCopyNoBuffer {
	public static void main(String[] args)throws IOException { 
		String inFileStr = "test-in.jpg"; 
		String outFileStr = "test-out.jpg";
		int byteRead; 
		long startTime, elapsedTime; // for speed benchmarking 

		// Print file length 
		File fileIn = new File(inFileStr); 
		System.out.println("File size is " + fileIn.length() + " bytes"); 

		try(FileInputStream in = new FileInputStream(inFileStr);
				FileOutputStream out = new FileOutputStream(outFileStr)) { 
			
			startTime = System.nanoTime(); 
			// Read a raw byte, returns an int of 0 to 255. 
			while ((byteRead = in.read()) != -1) { 
				// Write the least-significant byte of int, drop the upper 3 bytes 
				out.write(byteRead); 
			}
		
			elapsedTime = System.nanoTime() - startTime;
			System.out.println("Elapsed Time is " +	(elapsedTime / 1000000.0) + " msec"); 
		}
	}
}
