package simple.WithBufferExample;
import java.io.*; 

public class FileCopyUsingBufferedStream {
	public static void main(String[] args)throws IOException { 
		String inFileStr = "test-in.jpg"; 
		String outFileStr = "test-out.jpg"; 

		long startTime, elapsedTime; // for speed benchmarking 
		File fileIn = new File(inFileStr); // Check file length 
		System.out.println("File size is " + fileIn.length() + " bytes"); 
		try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(inFileStr)); 
				BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFileStr))) 
		{ 
			startTime = System.nanoTime(); 
			int byteRead; 
			while ((byteRead = in.read()) != -1) {
				out.write(byteRead); // Read byte-by-byte from buffer
			} 
			elapsedTime = System.nanoTime() - startTime; 
			System.out.println("Elapsed Time is " + (elapsedTime / 1000000.0) + 
					" msec"); 
		} 
	} 
}
