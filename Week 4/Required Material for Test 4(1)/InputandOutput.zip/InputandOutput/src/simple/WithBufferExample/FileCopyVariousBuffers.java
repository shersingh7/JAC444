package simple.WithBufferExample;
import java.io.*; 

public class FileCopyVariousBuffers {
	public static void main(String[] args) throws IOException{ 
		String inFileStr = "test-in.jpg"; 
		String outFileStr = "test-out.jpg"; 
		long startTime, elapsedTime; // for speed benchmarking 
		// Check file length File 
		File fileIn = new File(inFileStr); 
		System.out.println("File size is " + fileIn.length() + " bytes"); 
		int[] bufSizeKB = {1, 2, 4, 8, 16, 32, 64, 256, 1024}; // in KB 
		int bufSize; // in bytes
		for (int run = 0; run < bufSizeKB.length; ++run) { 
			bufSize = bufSizeKB[run] * 1024; 
			try (FileInputStream in = new FileInputStream(inFileStr); 
					FileOutputStream out = new FileOutputStream(outFileStr)) { 
				startTime = System.nanoTime(); 
				byte[] byteBuf = new byte[bufSize]; int numBytesRead; 
				while ((numBytesRead = in.read(byteBuf)) != -1) { 
					out.write(byteBuf, 0, numBytesRead); } 
				elapsedTime = System.nanoTime() - startTime; 
				System.out.printf("%4dKB: %6.2fmsec%n", bufSizeKB[run], (elapsedTime / 1000000.0));	
			} 
		} 
	}


}
