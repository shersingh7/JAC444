package simple.CharacterStream;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyCharacterExample {
	public static void main(String[] args) throws IOException {
		FileReader inputStream = null; 
		FileWriter outputStream = null; 
		try { 
			inputStream = new FileReader("in.txt"); 
			outputStream = new FileWriter("characteroutput.txt"); 
			
			int c; 
			while ((c = inputStream.read()) != -1) { 
				outputStream.write(c); 
			} 
		}     
		finally { 
			if (inputStream != null) { 
				inputStream.close(); 
			} 
			if (outputStream != null) { 
				outputStream.close(); 
			} 
		} 
	}

}


/*
package simple.CharacterStream;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyCharacterExample {
	@SuppressWarnings({ "resource" })
	public static void main(String[] args) throws IOException {
		BufferedReader bf =null;
		BufferedWriter bw =null;
		FileReader inputStream = null; 
		FileWriter outputStream = null; 
		try { 
			bf = new BufferedReader(new FileReader("BuffRead.txt"));
			bw = new BufferedWriter(new FileWriter("Buff.txt"));
			
			String line;
			while((line = bf.readLine()) != null) {
				bw.write(line);
				bw.newLine();
			}
			bw.flush();
			
		}     
		finally { 
			if (inputStream != null) { 
				inputStream.close(); 
			} 
			if (outputStream != null) { 
				outputStream.close(); 
			} 
		} 
	}

}
*/