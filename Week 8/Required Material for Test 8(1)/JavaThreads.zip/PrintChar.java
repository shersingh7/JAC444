public class PrintChar implements Runnable{

    private char aChar;
    private int times;

    public PrintChar(char c, int t){
        this.aChar = c;
        this.times = t;
    }

    @Override
    public void run(){
        for(int i=0; i<times; i++){
            System.out.print(" " + aChar);
        }
    }

}
