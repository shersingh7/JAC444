import java.util.*;
import java.util.concurrent.CopyOnWriteArraySet;

public class JavaThreads {
    public static void main(String...strings) {
        List<String> list = new ArrayList<>();
        Set<String> dp = new CopyOnWriteArraySet<>();

        dp.add("A");
        dp.add("A");
        dp.add("B");
        System.out.println(dp);

        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        for (int i = 0; i < list.size(); i++)
            System.out.print(list.remove(i));
        System.out.print(list);

    }
}
    /*demo();
    }

    private static void demo(){
        Object lock = new Object();
        Thread one = new Thread(new Runnable() {

            @Override
            public void run() {

                System.out.println("INFO: Thread One is waiting for the lock");
                synchronized (lock){
                    System.out.println("INFO: Thread One got the Lock");
                    System.out.println("One is printing - 1");
                }
                try{
                    System.out.println("INFO: Thread One is ready to go to the Wait state, giving up th econtrol");
                    lock.wait();
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("INFO: Thread Two wake up Thread One, and Thread one gains the lock");
                System.out.println("One is printing - 2");
                System.out.println("One is printing - 3");
            }
        });

        Thread two = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("INFO: Thread two is waiting for the lock");
                synchronized (lock) {
                    System.out.println("INFO: Thread two got the Lock");
                    System.out.println("Two is printing - 1");
                    System.out.println("Two is printing - 2");
                    System.out.println("Two is printing - 3");
                    System.out.println("INFO: Thread two end printing, and calling the notify method");
                    lock.notify();

                }
            }
        });

        one.start();
        two.start();
    }*/
        /*BankAccount task = new BankAccount();
        task.setBalance(100);

        Thread john = new Thread(task);
        Thread anita = new Thread(task);
        john.setName("John");
        anita.setName("Anita");

        anita.start();
        john.start();

    }
        static class BankAccount implements Runnable{
        private double balance;
        public void setBalance(double balance){
            this.balance = balance;
        }

        @Override
        public void run(){
            makeWithdraw(75);
            if(balance < 0){
                System.out.println("Money is OverDrawn!!");
            }
        }

        private synchronized void makeWithdraw(double amount){
            if(balance >= amount){
                System.out.println(Thread.currentThread().getName() + "is about to withdraw");
                balance -= amount;
                System.out.println(Thread.currentThread().getName() + "has withdrawn");

            }
            else
                System.out.println("Sorry not enough money" + Thread.currentThread().getName());


        }
    }*/

       /* //creating my tasks
        Runnable printChar = new PrintChar('a',10);
        Runnable printString = new PrintString("Hello", 10);
        Runnable printNum = new PrintNumber(10);

        //creating threads and passing the tasks to it
        Thread printCharThread = new Thread(printChar);
        Thread printStringThread = new Thread(printString);
        Thread printNumThread = new Thread(printNum);

        //thread-0, thread-1 ...
        printCharThread.setName("Thread for character");
        System.out.println(printCharThread.getName());


        //0 - 5 - 10
        printNumThread.setPriority(Thread.MAX_PRIORITY);

        //starting the threads
        printCharThread.start();
        printStringThread.start();
        try{
            printStringThread.join();
        }catch(InterruptedException e){
            e.printStackTrace();
        }

        printNumThread.start();

        //printCharThread.run();
        //printNumThread.run();

        //printCharThread.start();
*/


