public class PrintNumber implements Runnable{
    private int number;

    public PrintNumber(int n){
        this.number = n;
    }

    @Override
    public void run(){
        for(int i=0; i<number; i++){
            System.out.print(" "+number);
        }
    }
}
