package sample.Functional.TwoParameters;

@FunctionalInterface
public interface Summable {
	
	boolean evenSum(int x, int y);

}
