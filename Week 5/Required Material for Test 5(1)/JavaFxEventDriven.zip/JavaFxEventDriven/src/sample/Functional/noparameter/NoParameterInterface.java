package sample.Functional.noparameter;

@FunctionalInterface
interface NoParameterInterface {
	 void Hello();
}
