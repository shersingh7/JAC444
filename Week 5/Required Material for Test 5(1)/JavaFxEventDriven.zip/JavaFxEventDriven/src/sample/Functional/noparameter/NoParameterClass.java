package sample.Functional.noparameter;

public class NoParameterClass{
	public static void main(String[]  args) {
		NoParameterInterface msg = () -> {System.out.println( "Hello from me ccccc");};
		System.out.println( );
		msg.Hello();
	
	}	
}

