package sample.Functional.OneParameter;

@FunctionalInterface
interface OneParameterInterface {
	public int 	SquareValue(int value);
}
